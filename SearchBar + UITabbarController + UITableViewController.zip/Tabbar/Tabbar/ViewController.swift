//
//  ViewController.swift
//  Tabbar
//
//  Created by Yogesh Patel on 29/10/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemMint
    }


}

